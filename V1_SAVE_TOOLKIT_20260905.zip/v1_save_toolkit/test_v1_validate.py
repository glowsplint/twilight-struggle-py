# -*- coding: utf-8 -*-
"""test_v1_validate.py — 针对 v1_validate.py 的自包含单元测试。

只依赖 python 标准库 + pytest，不依赖仓库其余代码：
拷贝 tools/ 下两个文件即可在任何地方 `pytest test_v1_validate.py`。

覆盖：合法正文/TSX 样例、真实客户端行型、TSX 承诺一致性、
行型/结构/状态量错误、警告判定、CLI 退出码、--strict。
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from v1_validate import main, validate_text  # noqa: E402

# ---------------------------------------------------------------------------
# 合法样例(手写, 与规范 §4/§6 逐条对应)
# ---------------------------------------------------------------------------
VALID_BODY = (
    "SETUP: ThePakisCard will play as USSR.\n"
    "M31 will play as USA.\n"
    "Handicap influence: US +2\n"
    "Scenario: Standard\n"
    "Optional Cards Added\n"
    "Time per Player: 90 Minutes\n"
    "USSR +1 in Poland [0][1]\n"
    "USSR +1 in East Germany [0][4]\n"
    "US +1 in Iran [1][0]\n"
    "\n"
    "Turn 1, Headline Phase: De Gaulle Leads France* & Asia Scoring: "
    "USSR Headlines De Gaulle Leads France*\n"
    "US Headlines Asia Scoring\n"
    "Event: De Gaulle Leads France*\n"
    "US -2 in France [0][1]\n"
    "USSR +1 in France [0][2]\n"
    "De Gaulle Leads France* is now in play.\n"
    "\n"
    "Event: Asia Scoring\n"
    "USSR gains 1 VP. Score is USSR 1.\n"
    "\n"
    "Turn 1, USSR AR1: COMECON*: Coup (3 Ops):\n"
    "Target: Italy\n"
    "FAILURE: 1 [ + 3 - 2x2 = 0 ]\n"
    "USSR Military Ops to 3\n"
    "DEFCON degrades to 4\n"
    "\n"
    "Turn 1, US AR1: Duck and Cover: Space Race (3 Ops):\n"
    "Die roll: 2 -- Success! (Needed 3 or less)\n"
    "US advances to 1 in the Space Race.\n"
    "\n"
    "Turn 1, Cleanup: DEFCON improves to 5\n"
    "\n"
    "US wins by Victory Points\n"
)

VALID_TSX = {
    "format": "ts-espionnage-save",
    "version": 1,
    "capabilities": {
        "deterministic_replay": True,
        "engine_resume": False,
        "private_hands": True,
        "private_state_derivable_from_seed": True,
    },
    "position": {
        "turn": 1, "ar": 1, "ar_side": "US", "vp": -5, "defcon": 5,
        "map": {"Poland": [1, 0], "East_Germany": [4, 0], "Iran": [0, 1]},
        "discard": [], "removed": [], "limbo": [],
        "basket": {"USSR": [], "US": []},
        "draw_count": 60,
        "hands": {"USSR": ["NATO", "Vietnam_Revolts"], "US": ["COMECON"]},
    },
    "replay": {"seed": 7, "actions": ["Poland", "COMECON", "COUP", "Italy", "1"]},
}


def _tsx_block(ext):
    payload = json.dumps(ext, indent=2, sort_keys=True)
    return ('# TSX-BEGIN v1\n# TSX-DATA\n'
            + '\n'.join('# ' + ln for ln in payload.splitlines())
            + '\n# TSX-END\n')


def _valid_full():
    return VALID_BODY + '\n' + _tsx_block(VALID_TSX)


def _codes(rep):
    return set(c for c, _ in rep.errors)


# ---------------------------------------------------------------------------
# 合法输入
# ---------------------------------------------------------------------------
def test_valid_full_with_tsx():
    rep = validate_text(_valid_full(), 'mini.tsg')
    assert rep.ok, rep.errors
    assert not rep.warnings


def test_valid_pure_txt_without_tsx():
    rep = validate_text(VALID_BODY, 'mini.txt')
    assert rep.ok, rep.errors


def test_valid_real_client_styles():
    # 419 局真实客户端行型: 竞价/揭示/返还/陷阱/截断标题/子标签
    body = (
        "SETUP: bocchi152 bids 2 Influence for USSR\n"
        "gatsu_ bids 2 Influence for USSR\n"
        "TIE! Sides chosen randomly\n"
        "gatsu_ will play as USSR.\n"
        "bocchi152 will play as USA.\n"
        "Additional Influence from bidding: US +2\n"
        "Scenario: Turn Zero\n"
        "Alternative Space Race Track\n"
        "Optional Cards Added\n"
        "Promo Pack 1 Added\n"
        "Time per Player: 45 Minutes\n"
        "USSR +1 in East Germany [0][4]\n"
        "US +3 in West Germany [3][0]\n"
        "\n"
        "Turn 4, USSR AR1: Grain Sales To Soviets: Event: Grain Sales To Soviets\n"
        "USSR reveals Mideast Scoring\n"
        "USSR reveals Mideast Scoring from hand\n"
        "US returns Mideast Scoring to USSR\n"
        "Coup (2 Ops):\n"
        "Target: Argentina\n"
        "FAILURE: 2 [ + 2 - 2x2 = 0 ]\n"
        "US Military Ops to 2\n"
        "DEFCON degrades to 2\n"
        "\n"
        "Turn 4, US AR2: Bear Trap*: Event: Bear Trap*\n"
        "Bear Trap* is now in play.\n"
        "\n"
        "Turn 4, USSR AR3: Che: USSR discards Che\n"
        "Trap Roll: 4 <= 4 -- Trap Escaped\n"
        "Bear Trap* is no longer in play.\n"
        "\n"
        "Turn 4, US AR3: U2 Incident*: Place Influence (3 Ops):\n"
        "USSR has no cards in hand to reveal\n"
        "\n"
        "Turn 5, US AR8: Nuclear Subs*: Space Race (8 Ops):\n"
        "Die roll: 5 -- Failed! (Needed 4 or less)\n"
        "\n"
        "Turn 10, Headline Phase: DEFCON improves to 3\n"
    )
    rep = validate_text(body, 'real_style.txt')
    assert rep.ok, rep.errors
    # 截断/无终局只警告
    assert 'HEADLINE_TRUNCATED' in set(c for c, _ in rep.warnings)


# ---------------------------------------------------------------------------
# 错误: 结构
# ---------------------------------------------------------------------------
def test_error_empty():
    rep = validate_text('', 'e.txt')
    assert 'EMPTY' in _codes(rep)


def test_error_no_setup():
    rep = validate_text('*RESHUFFLE*\n\nSETUP: A will play as USSR.\n'
                        'B will play as USA.\n', 'e.txt')
    assert 'NO_SETUP' in _codes(rep)


def test_error_setup_missing_players():
    rep = validate_text('SETUP: A will play as USSR.\n', 'e.txt')
    assert 'SETUP_NO_USA' in _codes(rep)
    assert 'SETUP_NO_USSR' not in _codes(rep)


def test_error_headline_no_us():
    text = ('SETUP: A will play as USSR.\nB will play as USA.\n\n'
            'Turn 1, Headline Phase: Nasser* & NATO: USSR Headlines Nasser*\n'
            '\nUS wins by Victory Points\n')
    rep = validate_text(text, 'e.txt')
    assert 'HEADLINE_NO_US' in _codes(rep)


def test_error_unknown_line():
    text = VALID_BODY + 'GARBLED GARBLE\n'
    rep = validate_text(text, 'e.txt')
    assert 'UNKNOWN_LINE' in _codes(rep)


def test_error_ar_range_in_early_turn():
    text = VALID_BODY.replace('Turn 1, USSR AR1:', 'Turn 1, USSR AR7:')
    rep = validate_text(text, 'e.txt')
    assert 'AR_RANGE' in _codes(rep)


def test_error_ar_nonmonotonic():
    text = VALID_BODY.replace('Turn 1, US AR1:', 'Turn 1, US AR1:')  # 基础
    # 构造 AR 倒序: 插一行 AR2 后接 AR1
    text = text.replace('US wins by Victory Points',
                        'Turn 2, USSR AR2: NATO: Place Influence (1 Ops):\n'
                        'Turn 2, US AR1: NATO: Place Influence (1 Ops):\n'
                        'US wins by Victory Points')
    rep = validate_text(text, 'e.txt')
    assert 'AR_NONMONOTONIC' in _codes(rep)


def test_error_turn_out_of_range():
    # 注意: Cleanup 回合号不查(客户端怪癖), 仅 AR 头查回合范围
    text = VALID_BODY.replace('Turn 1, USSR AR1:', 'Turn 11, USSR AR1:')
    rep = validate_text(text, 'e.txt')
    assert 'TURN_RANGE' in _codes(rep)


def test_error_defcon_out_of_range():
    text = VALID_BODY.replace('DEFCON degrades to 4', 'DEFCON degrades to 6')
    rep = validate_text(text, 'e.txt')
    assert 'DEFCON_RANGE' in _codes(rep)


# ---------------------------------------------------------------------------
# 错误: TSX 块
# ---------------------------------------------------------------------------
def test_error_tsx_no_begin():
    text = (VALID_BODY + '\n# TSX-DATA\n# {}\n# TSX-END\n')
    rep = validate_text(text, 'e.txt')
    assert 'TSX_NO_BEGIN' in _codes(rep)


def test_error_tsx_no_end():
    text = VALID_BODY + '\n# TSX-BEGIN v1\n# TSX-DATA\n# {}\n'
    rep = validate_text(text, 'e.txt')
    assert 'TSX_NO_END' in _codes(rep)


def test_error_tsx_json():
    ext = json.loads(json.dumps(VALID_TSX))
    block = ('# TSX-BEGIN v1\n# TSX-DATA\n# {{{broken\n# TSX-END\n')
    rep = validate_text(VALID_BODY + '\n' + block, 'e.txt')
    assert 'TSX_JSON' in _codes(rep)


def test_error_tsx_version():
    ext = dict(VALID_TSX, version=2)
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_VERSION' in _codes(rep)


def test_error_tsx_replay_promise():
    ext = dict(VALID_TSX)
    ext['replay'] = {'seed': 7}          # 缺 actions
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_REPLAY_ACTIONS' in _codes(rep)

    ext = dict(VALID_TSX)
    del ext['replay']                    # 声明了 deterministic 但无 replay
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_REPLAY_SEED' in _codes(rep)


def test_error_tsx_hands_promise():
    ext = json.loads(json.dumps(VALID_TSX))
    del ext['position']['hands']         # 声明 private_hands 但无 hands
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_HANDS' in _codes(rep)


def test_error_tsx_duplicate_card():
    ext = json.loads(json.dumps(VALID_TSX))
    ext['position']['hands'] = {'USSR': ['NATO', 'NATO'], 'US': ['COMECON']}
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_DUP_CARD' in _codes(rep)


def test_error_tsx_zone_overlap():
    ext = json.loads(json.dumps(VALID_TSX))
    ext['position']['discard'] = ['NATO']      # 与手牌重叠
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_ZONE_OVERLAP' in _codes(rep)


def test_error_tsx_defcon():
    ext = json.loads(json.dumps(VALID_TSX))
    ext['position']['defcon'] = 6
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_DEFCON' in _codes(rep)


def test_error_tsx_cross_hand():
    ext = json.loads(json.dumps(VALID_TSX))
    ext['position']['hands'] = {'USSR': ['NATO'], 'US': ['NATO']}
    rep = validate_text(VALID_BODY + '\n' + _tsx_block(ext), 'e.txt')
    assert 'TSX_CROSS_HAND' in _codes(rep)


# ---------------------------------------------------------------------------
# 警告
# ---------------------------------------------------------------------------
def test_warn_missing_termination():
    text = VALID_BODY.rsplit('US wins by', 1)[0]
    rep = validate_text(text, 'e.txt')
    assert rep.ok
    assert 'NO_TERMINATION' in set(c for c, _ in rep.warnings)


def test_warn_unknown_card():
    text = VALID_BODY.replace('Event: Asia Scoring', 'Event: Kremlin Flu')
    rep = validate_text(text, 'e.txt')
    assert rep.ok
    assert 'CARD_TURN_ZERO' in set(c for c, _ in rep.warnings)


def test_strict_mode_fails_on_warnings():
    import io
    from contextlib import redirect_stdout

    class Args:
        pass

    # 临时文件含警告(无终局行)
    import tempfile
    fd, path = tempfile.mkstemp(suffix='.txt')
    try:
        os.write(fd, (VALID_BODY.replace('US wins by Victory Points', '')
                     ).rstrip().encode('utf-8'))
        os.close(fd)
        with redirect_stdout(io.StringIO()) as _buf:
            rc_ok = main(['-q', path])
            rc_strict = main(['--strict', '-q', path])
        assert rc_ok == 0
        assert rc_strict == 1
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def test_cli_detects_errors(tmp_path=None):
    import tempfile
    fd, path = tempfile.mkstemp(suffix='.txt')
    try:
        os.write(fd, b'GARBLED\n')
        os.close(fd)
        import io
        from contextlib import redirect_stdout
        with redirect_stdout(io.StringIO()) as _buf:
            rc = main(['-q', path])
        assert rc == 1
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


if __name__ == '__main__':
    raise SystemExit(main(['-q', __file__]))
