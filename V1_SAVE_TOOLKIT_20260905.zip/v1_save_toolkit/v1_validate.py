#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v1_validate.py — TSX V1（TS Espionnage save）棋谱/存档合法性验证器。

独立单文件，只依赖 Python 3 标准库，可在任何机器上对任意来源的 V1 文件验证。
规范依据：配套的 V1_SAVE_FORMAT_SPEC.md（行格式 4.x、TSX 块 6.x、验证清单 8.x）。

支持的输入：
  * 纯 TS Espionnage 棋谱文本（.txt，无 TSX 块）——真实 TSEspionage 导出；
  * 带 ``# TSX-BEGIN v1`` 块的 V1 存档（.tsg）——本仓库/按规范实现的生成器输出。

用法::

    python v1_validate.py path.tsg path.txt ...
    python v1_validate.py --strict path   # 警告也视为失败
    python v1_validate.py -q path         # 只打印错误

退出码: 0 = 通过（可带警告），1 = 有错误，2 = 用法错误。

验证原则（按规范"产出后必检"）：
  * 文本词表：每一非空行必须是规范 §4 行型之一（含在线对局/变体/Turn Zero 行）；
  * 结构约束：SETUP 在首、头条与 headline 行配对、行动轮数与回合匹配
    （T1-3 六轮 / T4-10 七轮、太空 8 格方八轮）、终局行在末尾；
  * 状态量约束：DEFCON 1-5、影响力括注非负、回合/行动轮单调；
  * TSX 块：marker 顺序、注释化 JSON、format/version、capabilities 与
    replay/hands 承诺一致性、position 字段类型与物理唯一性；
  * 卡名/国家名单：卡名须在规范 §5 显示表内（Turn Zero 场景牌仅警告）。
"""

from __future__ import annotations

import argparse
import json
import re
import sys

FORMAT_NAME = "ts-espionnage-save"
FORMAT_VERSION = 1
BEGIN_MARKER = "# TSX-BEGIN v1"
DATA_MARKER = "# TSX-DATA"
END_MARKER = "# TSX-END"

# ---------------------------------------------------------------------------
# 常量表（与规范 §四/§五一致，由仓库 419 局真实样本核对）
# ---------------------------------------------------------------------------
CARD_NAMES = [
    '"An Evil Empire"', '"Ask Not What Your Country..."', '"Lone Gunman"',
    '"One Small Step..."', '"We Will Bury You"', 'ABM Treaty',
    'AWACS Sale To Saudis', 'Africa Scoring', 'Aldrich Ames Remix', 'Allende',
    'Alliance For Progress', 'Arab-Israeli War', 'Arms Race', 'Asia Scoring',
    'Bear Trap', 'Blank 1 Op Card', 'Blank 2 Op Card', 'Blank 3 Op Card',
    'Blank 4 Op Card', 'Blockade', 'Brezhnev Doctrine', 'Brush War',
    'CIA Created', 'COMECON', 'Camp David Accords', 'Captured Nazi Scientist',
    'Central America Scoring', 'Che', 'Chernobyl', 'Colonial Rear Guards',
    'Containment', 'Cuban Missile Crisis', 'Cultural Revolution',
    'De Gaulle Leads France', 'De-Stalinization', 'Decolonization',
    'Defectors', 'Duck and Cover', 'East European Unrest', 'Europe Scoring',
    'Fidel', 'Five Year Plan', 'Flower Power', 'Formosan Resolution',
    'Glasnost', 'Grain Sales To Soviets', 'How I Learned To Stop Worrying',
    'Independent Reds', 'Indo-Pakistani War', 'Iran-Contra Scandal',
    'Iran-Iraq War', 'Iranian Hostage Crisis', 'John Paul II Elected Pope',
    'Junta', 'Kitchen Debates', 'Korean War', 'Latin American Death Squads',
    'Latin American Debt Crisis', 'Liberation Theology',
    'Marine Barracks Bombing', 'Marshall Plan', 'Mideast Scoring',
    'Missile Envy', 'Muslim Revolution', 'NATO', 'NORAD', 'Nasser',
    'Nixon Plays The China Card', 'North Sea Oil', 'Nuclear Subs',
    'Nuclear Test Ban', 'OAS Founded', 'OPEC', 'Olympic Games',
    'Ortega Elected in Nicaragua', 'Our Man in Tehran',
    'Panama Canal Returned', 'Pershing II Deployed',
    'Portuguese Empire Crumbles', 'Puppet Governments', 'Quagmire',
    'Reagan Bombs Libya', 'Red Scare/Purge', 'Romanian Abdication',
    'SALT Negotiations', 'Sadat Expels Soviets', 'Shuttle Diplomacy',
    'Socialist Governments', 'Solidarity', 'South African Unrest',
    'South America Scoring', 'Southeast Asia Scoring',
    'Soviets Shoot Down KAL-007', 'Special Relationship', 'Star Wars',
    'Suez Crisis', 'Summit', 'Tear Down This Wall', 'Terrorism',
    'The Cambridge Five', 'The China Card', 'The Iron Lady', 'The Reformer',
    'The Voice of America', 'Truman Doctrine', 'U2 Incident', 'UN Intervention',
    'US/Japan Mutual Defense Pact', 'Ussuri River Skirmish', 'Vietnam Revolts',
    'Wargames', 'Warsaw Pact Formed', 'Willy Brandt', 'Yuri and Samantha',
]
# Turn Zero 扩展场景卡（非标准 110 张，出现只警告）
TURN_ZERO_CARDS = {
    '1945 UK Election', 'VE Day', 'VJ Day', 'Chinese Civil War',
    'Kremlin Flu', 'Who Lost China', 'Berlin Wall', 'Mobutu Sese Seko',
}
CARD_NAMES_SET = set(CARD_NAMES)
TURN_ZERO_SET = CARD_NAMES_SET | TURN_ZERO_CARDS
# 国家显示名（区域牌组合名: Laos/Cambodia、Spain/Portugal；419 局真实样本零差异）
HOME_COUNTRY_NAMES = {
    'Afghanistan', 'Algeria', 'Angola', 'Argentina', 'Australia', 'Austria',
    'Benelux', 'Bolivia', 'Botswana', 'Brazil', 'Bulgaria', 'Burma',
    'Cameroon', 'Canada', 'Chile', 'Colombia', 'Costa Rica', 'Cuba',
    'Czechoslovakia', 'Denmark', 'Dominican Republic', 'East Germany',
    'Ecuador', 'Egypt', 'El Salvador', 'Ethiopia', 'Finland', 'France',
    'Greece', 'Guatemala', 'Gulf States', 'Haiti', 'Honduras', 'Hungary',
    'India', 'Indonesia', 'Iran', 'Iraq', 'Israel', 'Italy', 'Ivory Coast',
    'Japan', 'Jordan', 'Kenya', 'Laos/Cambodia', 'Lebanon', 'Libya',
    'Malaysia', 'Mexico', 'Morocco', 'Nicaragua', 'Nigeria', 'North Korea',
    'Norway', 'Pakistan', 'Panama', 'Paraguay', 'Peru', 'Philippines',
    'Poland', 'Romania', 'SE African States', 'Saharan States',
    'Saudi Arabia', 'Somalia', 'South Africa', 'South Korea',
    'Spain/Portugal', 'Sudan', 'Sweden', 'Syria', 'Taiwan', 'Thailand',
    'Tunisia', 'Turkey', 'UK', 'Uruguay', 'Venezuela', 'Vietnam',
    'West African States', 'West Germany', 'Yugoslavia', 'Zaire',
    'Zimbabwe',
}

# ---------------------------------------------------------------------------
# 行型词表（规范 §4）；(code, pattern)，匹配顺序无关
# ---------------------------------------------------------------------------
_LINE_PATTERNS = [
    ('SETUP', re.compile(r'^SETUP: ')),
    ('PLAYER', re.compile(r'^.* will play as (USSR|USA)\.$')),
    ('BID', re.compile(r'^.* bids \d+ Influence for (USSR|USA)$')),
    ('INFLUENCE_BIDDING',
     re.compile(r'^Additional Influence from bidding: (US|USSR) \+?\d+$')),
    ('HANDICAP', re.compile(r'^Handicap influence: (US|USSR) \+?\d+$')),
    ('SCENARIO', re.compile(r'^Scenario: .+')),
    ('OPTIONAL', re.compile(r'^Optional Cards Added$')),
    ('PROMO', re.compile(r'^Promo Pack \d+ Added$')),
    ('TIMEPLAYER', re.compile(r'^Time per Player: .+')),
    ('ALT_TRACK', re.compile(r'^Alternative Space Race Track$')),
    ('TIE', re.compile(r'^TIE! Sides chosen randomly$')),
    ('RESHUFFLE', re.compile(r'^\*RESHUFFLE\*$')),
    ('HEADLINE_TITLE', re.compile(r'^Turn \d+, Headline Phase:')),
    ('HEADLINE_TITLE_TRUNC', re.compile(r'^Turn \d+, Headline Phase$')),
    ('HEADLINE_USSR', re.compile(r'^USSR Headlines ')),
    ('HEADLINE_US', re.compile(r'^US Headlines ')),
    ('AR_HEADER', re.compile(r'^Turn \d+, (USSR|US) AR\d+')),
    ('CLEANUP', re.compile(r'^Turn \d+, Cleanup')),
    ('EVENT', re.compile(r'^Event: .+')),
    ('TARGET', re.compile(r'^Target: .+')),
    ('OUTCOME', re.compile(r'^(?:SUCCESS|FAILURE|VICTORY|DEFEAT): ')),
    ('ROLLS', re.compile(r'^(?:USSR|US) rolls .+$')),
    ('WAR', re.compile(r'^War in .+$')),
    ('DIE', re.compile(r'^Die roll: .+$')),
    ('TRAP', re.compile(r'^Trap Roll: .+$')),
    ('REROLL', re.compile(r'^Reroll: .+$')),
    ('INFLUENCE', re.compile(r'^(?:US|USSR) [+-]\d+ in .+ \[(\d+)\]\[(\d+)\]$')),
    ('VPGAIN', re.compile(r'^(?:US|USSR) gains \d+ VP\. ')),
    ('NOVP', re.compile(r'^No VP awarded\. ')),
    ('SCORE', re.compile(r'^Score is (?:USSR|US) \d+\.$|^Score is even\.$')),
    ('MILOPS', re.compile(r'^(?:US|USSR) Military Ops to \d+$')),
    ('DEFCON', re.compile(r'^DEFCON (degrades|improves) to \d+$')),
    ('SPACEADV',
     re.compile(r'^(?:US|USSR) advances to \d+ in the Space Race\.$')),
    ('BASKET', re.compile(r'^[A-Za-z0-9 /."*\'-]+ is (?:now|no longer) in play\.$')),
    ('DISCARD', re.compile(r'^(?:US|USSR) discards .+$')),
    ('REVEAL',
     re.compile(r'^(?:US|USSR|NEUTRAL) reveals .+?(?: from hand)?$')),
    ('PLAYS', re.compile(r'^(?:US|USSR|NEUTRAL) plays .+$')),
    ('RETURNS', re.compile(r'^(?:US|USSR) returns .+ to (?:USSR|US)$')),
    ('HAS_NONE', re.compile(
        r'^(?:US|USSR|NEUTRAL) has no cards (?:to (?:reveal|discard)|in hand to reveal)$')),
    ('CHOOSES', re.compile(r'^(?:US|USSR|NEUTRAL) chooses .+\.?$')),
    ('SELECTS', re.compile(r'^(?:US|USSR|NEUTRAL) selects .+\.$')),
    # 子标签行: UN Intervention/被中断行动的后续行动 (真实: "Coup (2 Ops):")
    ('SUBLABEL', re.compile(r'^(?:Place Influence|Coup|Realignment|Space Race|Skip Optional AR|No More Realignment)(?: \(\d+ Ops\))?:$')),
    ('WINS', re.compile(r'^[A-Za-z ."-]+ wins by .+$')),
    ('DRAW', re.compile(r'^Draw\.?$')),
]

_PATTERN_BY_CODE = dict(_LINE_PATTERNS)


def _norm_name(s: str) -> str:
    """大小写/分隔符无关归一: 'East_Germany' == 'East Germany' == 'EAST GERMANY'."""
    return (s.lower().replace('_', '').replace('-', '').replace('/', '')
            .replace(' ', '').replace('"', '').replace('.', '').replace("'", ''))


# 国家名显示式/引擎式双口径归一集(正文行用显示式, TSX position 用引擎式)
_HOME_COUNTRY_NORM = {_norm_name(n) for n in HOME_COUNTRY_NAMES}

_VP_GAIN = re.compile(r'^(?:US|USSR) gains (\d+) VP\. ')
_DEFCON_LINE = re.compile(r'^DEFCON (degrades|improves) to (\d+)$')
_INFLUENCE_BRACKET = re.compile(r'\[(\d+)\]\[(\d+)\]')
_HEADLINE_TITLE_MERGED = re.compile(r': (?:USSR|US) Headlines ')
_AR_SHAPE = re.compile(r'^Turn (\d+), (USSR|US) AR(\d+): (.*)$')
_CARD_LINE = re.compile(
    r'^(?:Event: )(?P<card1>.+)|'
    r'^(?:US|USSR|NEUTRAL) (?:reveals|discards|plays|selects) (?P<card2>.+?)(?: from hand)?$')
_INPUT_TYPES = {
    'SELECT_CARD', 'SELECT_COUNTRY', 'SELECT_CARD_ACTION', 'SELECT_MULTIPLE',
    'COMMIT', 'ROLL_DICE',
}


# ---------------------------------------------------------------------------
# 报告
# ---------------------------------------------------------------------------
class Report:
    """错误/警告收集。code 稳定可用于测试断言。"""

    def __init__(self, path: str = ''):
        self.path = path
        self.errors = []      # (code, detail)
        self.warnings = []    # (code, detail)

    def err(self, code: str, detail: str):
        self.errors.append((code, detail))

    def warn(self, code: str, detail: str):
        self.warnings.append((code, detail))

    @property
    def ok(self) -> bool:
        return not self.errors

    def __bool__(self):
        return self.ok

    def render(self, verbose: bool = True) -> str:
        lines = []
        for code, detail in self.errors:
            lines.append(f'ERROR [{code}] {detail}')
        if verbose:
            for code, detail in self.warnings:
                lines.append(f'WARN  [{code}] {detail}')
        if not lines:
            lines.append('OK (no issues)')
        elif self.ok:
            lines.append(f'OK: {len(self.warnings)} warning(s)')
        else:
            lines.append(f'FAILED: {len(self.errors)} error(s)')
        return '\n'.join(lines)


# ---------------------------------------------------------------------------
# 正文验证
# ---------------------------------------------------------------------------
def _validate_body(lines: list, rep: Report) -> None:
    nonzero = [i for i, ln in enumerate(lines) if ln.strip()]

    # -- 结构: SETUP 首行 ----------------------------------------------------
    if not nonzero:
        rep.err('EMPTY', 'file has no non-blank lines')
        return
    first = nonzero[0]
    if not _PATTERN_BY_CODE['SETUP'].match(lines[first]):
        rep.err('NO_SETUP', 'first non-blank line must start with "SETUP: "')
    play_ussr = play_us = False
    for ln in lines[first:first + 8]:
        m = re.match(r'^.+ will play as (USSR|USA)\.$', ln)
        if m:
            if m.group(1) == 'USSR':
                play_ussr = True
            else:
                play_us = True
    if not play_ussr:
        rep.err('SETUP_NO_USSR', 'missing "<name> will play as USSR." line')
    if not play_us:
        rep.err('SETUP_NO_USA', 'missing "<name> will play as USA." line')

    # -- 终局行: 必须为最后非空行 --------------------------------------------
    last = nonzero[-1]
    if not (_PATTERN_BY_CODE['WINS'].match(lines[last])
            or _PATTERN_BY_CODE['DRAW'].match(lines[last])):
        rep.warn('NO_TERMINATION',
                 'last non-blank line is not "{winner} wins by ..." / "Draw." '
                 '(半途/中局存档允许出现此警告)')

    # -- 词表 ----------------------------------------------------------------
    for i, ln in enumerate(lines):
        if not ln.strip():
            continue
        if not any(p.match(ln) for _, p in _LINE_PATTERNS):
            rep.err('UNKNOWN_LINE', f'line {i + 1}: {ln[:100]!r}')

    # -- 头条配对 ------------------------------------------------------------
    for i, ln in enumerate(lines):
        if not _PATTERN_BY_CODE['HEADLINE_TITLE'].match(ln):
            continue
        merged = _HEADLINE_TITLE_MERGED.search(ln)
        merged_ussr = bool(merged and merged.group(0).split(' ')[1] == 'USSR')
        merged_us = bool(merged and merged.group(0).split(' ')[1] == 'US')
        window = [l for l in lines[i + 1:i + 8] if l.strip()]
        have_ussr, have_us = merged_ussr, merged_us
        for l in window:
            if _PATTERN_BY_CODE['HEADLINE_USSR'].match(l):
                have_ussr = True
            elif _PATTERN_BY_CODE['HEADLINE_US'].match(l):
                have_us = True
        # 标题行不含 '&'(无卡名)是客户端中断对局的截断条目(3235181 等)
        truncated = '&' not in ln
        if not have_ussr:
            if truncated:
                rep.warn('HEADLINE_TRUNCATED', f'line {i + 1}: incomplete '
                        'headline title (no cards), missing "USSR Headlines X"')
            else:
                rep.err('HEADLINE_NO_USSR', f'line {i + 1}: headline title '
                        'lacks "USSR Headlines X"')
        if not have_us:
            if truncated:
                rep.warn('HEADLINE_TRUNCATED', f'line {i + 1}: incomplete '
                        'headline title (no cards), missing "US Headlines X"')
            else:
                rep.err('HEADLINE_NO_US', f'line {i + 1}: headline title '
                        'lacks "US Headlines X"')

    # -- AR 编号与回合规则(T1-3=6轮, T4-10=7轮, AR8 仅太空8格) -----------------
    prev_turn = 0
    prev_ar = 0
    for i, ln in enumerate(lines):
        m = _AR_SHAPE.match(ln)
        if not m:
            continue
        turn, ar = int(m.group(1)), int(m.group(3))
        if not (1 <= turn <= 10):
            rep.err('TURN_RANGE', f'line {i + 1}: turn {turn} out of 1..10')
        max_ar = 6 if turn <= 3 else 7
        if ar < 1:
            rep.err('AR_RANGE', f'line {i + 1}: AR{ar} < 1')
        elif ar > max_ar and ar != 8:
            rep.err('AR_RANGE', f'line {i + 1}: AR{ar} > {max_ar} for turn '
                    f'{turn} (T1-3=6轮, T4-10=7轮; AR8 仅太空8格方)')
        if turn == prev_turn and ar < prev_ar:
            rep.err('AR_NONMONOTONIC',
                    f'line {i + 1}: AR{ar} after AR{prev_ar} in turn {turn}')
        if turn < prev_turn:
            rep.err('TURN_NONMONOTONIC',
                    f'line {i + 1}: turn {turn} after turn {prev_turn}')
        if turn > prev_turn:
            prev_ar = 0
        prev_turn, prev_ar = turn, ar

    # -- 状态量 --------------------------------------------------------------
    for i, ln in enumerate(lines):
        m = _DEFCON_LINE.match(ln)
        if m:
            val = int(m.group(2))
            if not (1 <= val <= 5):
                rep.err('DEFCON_RANGE', f'line {i + 1}: DEFCON {val} out of 1..5')
        m = re.search(r'Score is (?:USSR|US) (\d+)\.', ln)
        if m and abs(int(m.group(1))) > 100:
            rep.warn('VP_RANGE', f'line {i + 1}: huge VP {m.group(1)}')
        if _PATTERN_BY_CODE['INFLUENCE'].match(ln):
            for m in _INFLUENCE_BRACKET.finditer(ln):
                us_v, ussr_v = int(m.group(1)), int(m.group(2))
                if us_v > 15 or ussr_v > 15:
                    rep.warn('INFLUENCE_RANGE',
                             f'line {i + 1}: [{us_v}][{ussr_v}] > 15')
            name = re.sub(r'^(?:US|USSR) [+-]\d+ in ', '', ln)
            name = re.sub(r' \[.*$', '', name)
            if _norm_name(name) not in _HOME_COUNTRY_NORM:
                rep.warn('COUNTRY_NAME', f'line {i + 1}: unknown country {name!r}')

    # -- 卡名(警告级: 标准 110 张外可能是 Turn Zero/改名) ----------------------
    for i, ln in enumerate(lines):
        m = _CARD_LINE.match(ln)
        if not m:
            continue
        name = (m.group('card1') or m.group('card2') or '').replace('*', '').strip()
        if not name:
            continue
        if name not in CARD_NAMES_SET:
            if name in TURN_ZERO_CARDS:
                rep.warn('CARD_TURN_ZERO', f'line {i + 1}: Turn Zero card {name!r}')
            else:
                rep.warn('CARD_NAME', f'line {i + 1}: unknown card {name!r}')


# ---------------------------------------------------------------------------
# TSX 块验证
# ---------------------------------------------------------------------------
def _split_body(text: str) -> str:
    """去掉 TSX 块后的正文。无 BEGIN 时原样返回。"""
    return text.split('\n' + BEGIN_MARKER + '\n')[0]


def _validate_tsx(text: str, rep: Report) -> None:
    parts = text.split('\n' + BEGIN_MARKER + '\n')
    if len(parts) > 2:
        rep.err('TSX_DUP', 'more than one "# TSX-BEGIN v1" marker')
        return
    if len(parts) == 1:
        if '# TSX-DATA' in text or '# TSX-END' in text:
            rep.err('TSX_NO_BEGIN', '"# TSX-DATA"/"# TSX-END" without BEGIN marker')
        return
    block = parts[1].splitlines()
    if not block:
        rep.err('TSX_NO_DATA', 'expected "# TSX-DATA" right after BEGIN marker')
        return
    if block[-1] != END_MARKER:
        rep.err('TSX_NO_END', 'missing "# TSX-END" at end of block')

    # 单行旧式 "# TSX-DATA {...}" 与新式 "# TSX-DATA" + "# {...}" 兼容
    if block[0].startswith(DATA_MARKER + ' '):
        if len(block) != 2:
            rep.err('TSX_LEGACY_SHAPE',
                    'single-line TSX-DATA form must be followed only by TSX-END')
            return
        payload = block[0][len(DATA_MARKER) + 1:]
    elif block[0] == DATA_MARKER:
        json_lines = block[1:-1]
        for j, ln in enumerate(json_lines):
            if not ln.startswith('# '):
                rep.err('TSX_COMMENT', f'TSX line {j + 1}: JSON line must start "# "')
        payload = '\n'.join(ln[2:] for ln in json_lines if ln.startswith('# '))
    else:
        rep.err('TSX_NO_DATA', 'expected "# TSX-DATA" right after BEGIN marker')
        return

    try:
        ext = json.loads(payload)
    except (TypeError, ValueError) as exc:
        rep.err('TSX_JSON', f'JSON parse failed: {exc}')
        return
    if not isinstance(ext, dict):
        rep.err('TSX_TYPE', 'TSX payload must be a JSON object')
        return
    if ext.get('format') != FORMAT_NAME:
        rep.err('TSX_FORMAT', f'format must be {FORMAT_NAME!r}')
        return
    if ext.get('version') != FORMAT_VERSION:
        rep.err('TSX_VERSION', f'version must be {FORMAT_VERSION}')
        return

    caps = ext.get('capabilities') or {}
    replay = ext.get('replay') or {}
    position = ext.get('position') or {}
    if not isinstance(caps, dict) or not isinstance(replay, dict) \
            or not isinstance(position, dict) or not position:
        rep.err('TSX_SHAPE', 'capabilities/replay/position must be objects')

    # -- capabilities ↔ replay/hands 承诺 ------------------------------------
    if caps.get('deterministic_replay'):
        if not isinstance(replay.get('seed'), int):
            rep.err('TSX_REPLAY_SEED',
                    'deterministic_replay=true but replay.seed missing/not int')
        if not isinstance(replay.get('actions'), list):
            rep.err('TSX_REPLAY_ACTIONS',
                    'deterministic_replay=true but replay.actions missing/not list')
    elif replay:
        rep.err('TSX_REPLAY_ORPHAN',
                'replay present but deterministic_replay not declared')
    if caps.get('private_hands'):
        hands = position.get('hands')
        if not isinstance(hands, dict) \
                or not isinstance(hands.get('USSR'), list) \
                or not isinstance(hands.get('US'), list):
            rep.err('TSX_HANDS', 'private_hands=true but position.hands missing')
        elif (position.get('input') or {}).get('options_redacted'):
            rep.err('TSX_HANDS_REDACTED',
                    '含双手牌时输入选项不应被隐去(capabilities 不一致)')

    # -- position 字段 --------------------------------------------------------
    if not isinstance(position, dict):
        return
    for field in ('turn', 'ar', 'vp', 'defcon'):
        if field in position and not isinstance(position[field], int):
            rep.err('TSX_POSITION_TYPE', f'position.{field} must be int')
    if isinstance(position.get('defcon'), int) \
            and not (1 <= position['defcon'] <= 5):
        rep.err('TSX_DEFCON', f'position.defcon {position["defcon"]} out of 1..5')
    if isinstance(position.get('turn'), int) \
            and not (0 <= position['turn'] <= 10):
        rep.err('TSX_TURN', f'position.turn {position["turn"]} out of 0..10')
    if isinstance(position.get('ar'), int) and position['ar'] < 0:
        rep.err('TSX_AR', f'position.ar {position["ar"]} < 0')
    if 'ar_side' in position and position['ar_side'] not in ('USSR', 'US', 'NEUTRAL'):
        rep.err('TSX_AR_SIDE', f'position.ar_side {position["ar_side"]!r} invalid')
    if isinstance(position.get('map'), dict):
        for name, vals in position['map'].items():
            if (not isinstance(vals, list) or len(vals) != 2
                    or not all(isinstance(v, int) and v >= 0 for v in vals)):
                rep.err('TSX_MAP',
                        f'position.map[{name!r}] must be [USSR, US] nonneg ints')
            elif sum(vals) > 15:
                rep.warn('TSX_INFLUENCE_RANGE', f'position.map[{name!r}] {vals} > 15')
            if _norm_name(name) not in _HOME_COUNTRY_NORM:
                rep.warn('TSX_COUNTRY', f'position.map has unknown country {name!r}')

    # -- 物理唯一性(hand ∩ discard/removed/limbo/basket) ----------------------
    hands = position.get('hands')
    if isinstance(hands, dict):
        shell = []
        for side in ('USSR', 'US'):
            lst = hands.get(side, []) or []
            dup = [c for c in set(lst) if lst.count(c) > 1]
            if dup:
                rep.err('TSX_DUP_CARD', f'{side} hand has duplicate cards: {dup}')
            shell.extend(lst)
        if len(shell) != len(set(shell)):
            rep.err('TSX_CROSS_HAND', 'a card appears in both hands')
        for zone in ('discard', 'removed', 'limbo'):
            for card in position.get(zone, []) or []:
                if card in shell:
                    rep.err('TSX_ZONE_OVERLAP',
                            f'card {card!r} in both hands and {zone}')
        for side in ('USSR', 'US'):
            for eff in (position.get('basket', {}).get(side, []) or []):
                if eff in shell:
                    rep.err('TSX_BASKET_OVERLAP',
                            f'effect {eff!r} in hand and basket')

    # -- input ---------------------------------------------------------------
    inp = position.get('input')
    if isinstance(inp, dict):
        if inp.get('type') not in _INPUT_TYPES:
            rep.err('TSX_INPUT_TYPE', f"position.input.type {inp.get('type')!r} invalid")
        if inp.get('side') not in ('USSR', 'US', 'NEUTRAL'):
            rep.err('TSX_INPUT_SIDE', f"position.input.side {inp.get('side')!r} invalid")


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------
def validate_text(text: str, path: str = '') -> Report:
    rep = Report(path)
    _validate_body(_split_body(text).splitlines(), rep)
    _validate_tsx(text, rep)
    return rep


def validate_file(path: str) -> Report:
    try:
        text = open(path, encoding='utf-8', errors='replace').read()
    except OSError as exc:
        rep = Report(path)
        rep.err('IO', f'cannot read: {exc}')
        return rep
    return validate_text(text, path)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description='Validate TSX V1 / TS Espionnage save text files.')
    ap.add_argument('paths', nargs='+', help='.txt / .tsg files')
    ap.add_argument('--strict', action='store_true',
                    help='treat warnings as errors')
    ap.add_argument('-q', '--quiet', action='store_true',
                    help='print errors only')
    args = ap.parse_args(argv)

    rc = 0
    for path in args.paths:
        rep = validate_file(path)
        print(f'== {path} ==')
        print(rep.render(verbose=not args.quiet))
        if rep.errors or (args.strict and rep.warnings):
            rc = 1
    return rc


if __name__ == '__main__':
    sys.exit(main())
