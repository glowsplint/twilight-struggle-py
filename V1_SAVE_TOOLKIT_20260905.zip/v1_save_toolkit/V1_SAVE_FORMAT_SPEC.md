# V1 存档规范（TS Espionnage 兼容扩展，对外）

> 面向把 V1 存档集成进自己项目的开发者。本文回答三件事：
> **V1 是什么、V1 相对 TSEspionage 棋谱改进了什么、别人如何按照本文产出 V1 存档。**
> 2026-09-05 编写。仓库内实现：`ts_record.py`（正文渲染） + `ts_save.py`（TSX 块）；格式快览见
> [TSX_SAVE_FORMAT.md](TSX_SAVE_FORMAT.md)。

---

## 一、背景：TSEspionage 棋谱是怎么来的

Playdek 的《冷战热斗》客户端（Steam 版）内部维护一份 UI 日志（`GameLog` 的
`m_logItemList`，条目含 `name / desc / detail` 三段文本）。**TSEspionage MOD 本身不
产生任何日志内容**：它只是把客户端这些条目原样导出到
`Documents\Twilight Struggle\<gameId>.txt`，每行按 `name: desc: detail` 拼接
（`GameLogPatches.UpdateGameLogPatch` 抓取 → `GameLogWriter.Write` 写出），并在
终局追加一行 `{玩家} wins by {GameOverType}`（8 类：Victory Points / Europe
Control / Final Scoring / DEFCON / Held Scoring Card / Cuban Missile Crisis /
WarGames / Forfeit）。

你看到的那份"TSEspionage 棋谱"，本质是**客户端自己打的日志**. 这也带来几个
客户端固有毛病（419 局真实样本核实）：

| 客户端缺陷 | 表现 |
| --- | --- |
| `Turn N, Cleanup` 的回合号错乱 | 该数字**同一局内恒定**（对局记录里 3/4/5/6/7/8/9 都有），与当前真实回合无关；如 8 回合局 T1 末也写 `Turn 8`，10 回合局写 `Turn 9` 等 |
| 整行重复 | 同一事件的 `Event: X` 偶发双行（村夫谱/3325831 可见，419 局中 `AR1` 行数也略多于正常值，如 16 vs 14） |
| 每局差异大 | 同名事件在不同局里"挂在"的行动位置不同（事件前/后结算顺序取决出牌时机），逐行复现只能按语义对齐 |

**行动轮数量务必注意**（规则书 4.x D）：`Turn 1-3 六个行动轮；Turn 4-10 七个
行动轮`；太空竞赛达到 8 格的那一方当日可打 **8 个行动轮**（规则书 6.4.4，
我方引擎 `ARS_BY_TURN = (None, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7)`，419 局统计
T4-T10 出现 `AR7`、T8-T10 部分局出现 `AR8`）。**客户端写 `AR7`/`AR8` 是
正确的，不是溢出**——旧文案曾误判为 bug，特此更正。

---

## 二、V1 是什么

V1 存档（扩展名 `.tsg`）是**一个文件，两个部分**：

```
<TS Espionnage 正文>          ← 与 TSEspionage 棋谱同方言的英文棋谱（纯文本）
# TSX-BEGIN v1                ← 追加的注释化 JSON 块（ts_save.py, FORMAT_VERSION=1）
# TSX-DATA
# { ... }
# TSX-END
```

关键设计：**正文永远是标准前缀，追加块是逐行 `# ` 注释的 JSON**。只认识 TSEspionage
的工具把 TSX 块当注释忽略，解析结果与纯正文完全一致；认识 TSX 的工具拿到
`position`（精确局面）与 `replay`（确定性重放）。仓库内的保存管线：

```powershell
# HVS（人机/观战）自动落盘：终局 <mode>_<时间>.tsg + 半途镜像 <mode>_running.tsg
# 网页"存档"按钮导出（2 个独立选项：随机种子 / 双方手牌）
tools/ts -m hvs.launch --save-dir log/hvs ...
```

转换/入口：`ts_save.build_save_text(espionnage_text, game, include_seed=..., seed=...,
player_actions=..., include_hands=...)`；解析：`ts_save.split_save_text(text)`；
仅正文重放解析 `rl.replay_parser.parse_espionnage`。

---

## 三、V1 相对原始 TSEspionage 棋谱的改进

| # | 改进 | 说明 |
| --- | --- | --- |
| 1 | **正文逐行对齐真实 TSEspionage 方言** | 卡名（连字符/斜杠/引号/星号）、国家名、`[US][USSR]` 括注、陷阱行、政变修正段、对齐双方修正、去句号规则等全部对齐 4 局真实样本（2026-09-05 后：`Trap Roll: d <= 4 -- Trap Escaped` 等细节取自已反编译的游戏字符串表） |
| 2 | **修复客户端 bug 数字** | Cleanup 写真实回合（`Turn 1, Cleanup` 而不是客户端的恒定计数 `Turn 8/9` 等）；行动轮号按规则书正确取值（T1-3 六轮、T4-10 七轮、太空 8 格八轮），与客户端语义一致 |
| 3 | **确定性重放** | `replay.seed + replay.actions` 可从标准开局精确重建到存档点（恢复引擎阶段栈与随机结果），不再是"只读展示"的文本 |
| 4 | **私有信息显式化** | `position.hands`（双方手牌）、`headline`（未揭示头条）、`card_state`（中国牌正反面、Missile Envy exchange）——TSEspionage 永不包含手牌 |
| 5 | **精确局面快照** | `position`：整图 84 国影响力、VP/DEFCON/军备/太空/回合/行动方、弃牌/移除/持续效果/牌堆计数、当前输入（提示+合法选项） |
| 6 | **双读兼容** | 旧工具照旧解析；新工具零解析成本拿到一切。`.`txt 纯正文可公开发布，`.tsg` 含私有块的留本机（HVS 只发布 txt 到 web 棋谱列表，TSX 块不进网络流） |
| 7 | **可编辑/可派生** | `position` 可人工改写摆局面（播放器显示层）；`hvs.fork_from_save` 可从残局转 v2 可玩支线（见 [TSX_SAVE_FORMAT.md](TSX_SAVE_FORMAT.md) §从 v1 残局 fork） |

---

## 四、正文行格式规范（对方照此输出）

> 以下全部行均有真实样本/游戏字符串背书。解析锚点契约以 `ts_record.py` 模块 docstring 为准。

### 4.1 SETUP

```
SETUP: {USSR玩家名} will play as USSR.
{US玩家名} will play as USA.
Handicap influence: US +2          ← 无句号；AI 对局形式
Scenario: Standard
Optional Cards Added
Time per Player: 90 Minutes
USSR +4 in Poland [0][4]           ← 逐点放置；[US影响力][USSR影响力]
US +1 in Iran [1][0]
```

**在线对局/变体行**（419 局词表统计；V1 按自己的对局配置选择其一即可）：

```
bocchi152 bids 2 Influence for USSR        ← 拍卖式开局侧别竞价(双方各一行)
TIE! Sides chosen randomly                 ← 竞拍平局随机定侧别
Additional Influence from bidding: US +2    ← 竞拍加码(替代 Handicap influence 行)
Scenario: Turn Zero                        ← Turn Zero 扩展场景
Alternative Space Race Track               ← 变体太空轨道
Promo Pack 1 Added / Promo Pack 2 Added    ← 推广包
```

### 4.2 头条块

```
Turn 3, Headline Phase: A* & B: USSR Headlines A*     ← 无 DEFCON/RESHUFFLE 时合并
US Headlines B
```
有回合末 DEFCON 恢复或洗牌时拆行（真实见 3305175 行 112/226）：

```
Turn 3, Headline Phase: A & B: DEFCON improves to 3
*RESHUFFLE*                        ← 仅回合发牌洗牌时出现；开局的发牌不输出
USSR Headlines A
US Headlines B

Event: A*                          ← 每个头条事件一段，段间空行
...效果差行...

Event: B
...
```

### 4.3 行动轮块

```
Turn 1, USSR AR1: COMECON*: Coup (3 Ops):              ← ops 模式
Turn 1, USSR AR1: Korean War*: Event: Korean War*      ← 事件模式
Turn 3, USSR AR1: The Cambridge Five: Event: The Cambridge Five   ← 无星=非唯一事件
Turn 3, US AR4: Blockade*: Coup (1 Ops):               ← 对方牌 ops 打出
                                                   （敌事件按 5.2 规则自动触发，见 4.6）
```

> **AR 编号规则**：`T1-T3` 六轮（AR1-6）；`T4-T10` 七轮（AR1-7）；太空竞赛
> 达到 8 格的一方当回合八轮（AR1-8）。内部示例中出现 `AR7/AR8` 是正常值。
QBT 陷阱弃牌块（真实见 3325831 行 329/543）——头部合一 + 陷阱行：

```
Turn 4, USSR AR1: Our Man in Tehran*: USSR discards Our Man in Tehran*
Trap Roll: 2 <= 4 -- Trap Escaped
Bear Trap* is no longer in play.
```
未逃脱：`Trap Roll: 6 > 4 -- Trap Remains in Effect`（字符串取自游戏本体）。

### 4.4 行动内容行

| 行 | 格式 | 说明 |
| --- | --- | --- |
| 政变目标 | `Target: Italy` | |
| 政变结果 | `SUCCESS: 3 [ + 2 - 2x2 = 1 ]` | 无修正段（单空格） |
| 政变结果（有修正） | `SUCCESS: 3 [ + 1 (-1)  - 2x1 = 1 ]` | 修正段 `(+/-n)` 双空格；修正源=LADS/SALT（见 6.3.x 与引擎 `_coup_modifier`） |
| 战争 | `War in Israel` + `VICTORY: 6 (-2)  >= 4` | 修正仅为相邻控制/目标自身；mod=0 时 `VICTORY: 4 >= 4`（单空格）；无独立骰行 |
| 对齐 | `USSR rolls 3 (+1) = 4` / `US rolls 2` | **每方各自修正**（规则书 6.2.2：+1 相邻控制、+1 目标影响力多、+1 己方超级大国相邻；Iran Contra 时 US 每骰 -1）；修正 0 时省略；**无句号** |
| 太空 | `Die roll: 2 -- Success! (Needed 3 or less)` | Failed 同理（`Failed!`，保持真实客户端大小写） |
| 计分骰/其他 | `USSR rolls 5` / `US rolls 1` | 无句号（所有 rolls 行统一无句号；419 局校验含正/负修正两侧变体） |
| Olympic 重掷 | `Reroll: 6 3` | 引擎 `2d6 roll (Sponsor roll, Participant roll)` 特判；无句号 |
| Grain Sales 事件 | `USSR reveals X` + `USSR reveals X from hand` + `US returns X to USSR` | 真实格式见 对局记录 3247482 行 448-450；随后用 Grain Sales 自身 ops 时以子标题行渲染 |
| 影响力 | `USSR +1 in East Germany [0][5]` / `US -1 in France [2][0]` | 差行，`[US][USSR]` 为**绝对值**；US 行在 USSR 行前 |
| 太空推进 | `USSR advances to 1 in the Space Race.` | 在 VP 行前 |
| VP | `USSR gains 2 VP. Score is USSR 4.` | 单行；`Score is US 4.` / `Score is even.` |
| 无 VP | `No VP awarded. Score is even.` | 计分牌净 0 时显式输出 |
| 军备 | `USSR Military Ops to 3` | **归零清零不输出** |
| DEFCON | `DEFCON degrades to 4` / `DEFCON improves to 3` | |
| 持续效果 | `Containment* is now in play.` / `Formosan Resolution* is no longer in play.` | |
| 弃牌 | `USSR discards Mideast Scoring` | **无句号**；常规弃牌（刚打出的牌进弃牌堆）不输出，只输出 FYP/QBT/UN/事件类有信息量的弃牌 |
| 揭示 | `USSR reveals Duck and Cover`（每卡一行）/ `US has no cards to reveal` | CIA Created（USSR 全手牌）、Lone Gunman（US 全手牌）、Cambridge Five（US 计分牌） |
| UN 介入 | `USSR plays Duck and Cover` | 事件段内；随后无弃置行 |
| 采买选择等 | `USSR chooses ...` / `US selects X.` / `NEUTRAL selects X.` | 泛化行（引擎选项文本），无真实样本对照的事件（Olympic/Grain Sales/Summit）保留作为兜底 |

### 4.5 差行顺序

按真实样本统计：**influence → space → VP → milops → defcon → basket → discards**。
（KAL-007 为已知反例：DEFCON 在 VP 前，客户端按引擎执行序，固定序无法覆盖。）

### 4.6 事件段（对手牌/被打断的事件）

对方牌以 ops 打出时，其事件按规则书 5.2 自动触发。真实格式 = 块内独立段（前空行）:

```
Turn 1, USSR AR2: Containment*: Place Influence (3 Ops):
USSR +3 in France [1][4]

Event: Containment*
Containment* is now in play.
```
"行动后触发"事件（如 Cambridge Five 展示、U2 Incident、Five Year Plan）
在**块末**单独成段。头条夹带事件由 dispose 钩子分割。

### 4.7 回合末与终局

```
Turn 1, Cleanup: USSR gains 3 VP. Score is USSR 4.   ← 首差行并入标题；无内容也输出 `Turn N, Cleanup`
Containment* is no longer in play.

USSR wins by DEFCON          ← 无句号；类型映射见 4.8；平局 `Draw.`
```

**回合末规则**：跨回合 gap 中 `DEFCON improves to N` 行延迟到下一块头条标题行尾；
其余行进 `Turn N, Cleanup` 块（turn 号用真实回合，不用客户端的 bug 数字）。

### 4.8 终局类型映射

| 引擎 reason | 输出 | 客户端 GameOverType |
| --- | --- | --- |
| `thermonuclear_war` | `DEFCON` | DEFCON |
| `vp_autovictory` | `Victory Points` | VictoryPoints |
| `wargames` | `WarGames` | Wargames |
| `held_scoring_card` | `Held Scoring Card` | HeldCards |
| `final_scoring_complete` | `Final Scoring` | FinalScoring |
| `europe_control` | `Europe Control` | EuropeControl |
| `deck_exhausted` | `Forfeit` | Forfeit |

---

## 五、名称显示规范

| 内容 | 规则 | 实例 |
| --- | --- | --- |
| 卡名 | 基础名 + （`event_unique`）`*` 后缀；`_` → 空格；Playdek 显示表（`ts_record.py::_PLAYDEK_CARD_NAMES`，419 局词表核对）特例 21 张：连字符 `Arab-Israeli War`/`Iran-Iraq War`/`Iran-Contra Scandal`/`KAL-007`/`De-Stalinization`、斜杠 `Red Scare/Purge`/`US/Japan Mutual Defense Pact`、大小写 `Mideast Scoring`/`SALT Negotiations`/`Alliance For Progress`/`AWACS Sale To Saudis`/`How I Learned To Stop Worrying`、虚词小写 `The Voice of America`/`Our Man in Tehran`、引号 `"We Will Bury You"`/`"One Small Step..."`/`"Lone Gunman"`/`"An Evil Empire"`、截断 `"Ask Not What Your Country..."` | `US/Japan Mutual Defense Pact*` |
| 国家名 | `_` → 空格；2 张斜杠特例：`Spain/Portugal`、`Laos/Cambodia`；**无英文单复数/大小写改写** | `Spain/Portugal` |

---

## 六、TSX v1 块规范

```
# TSX-BEGIN v1
# TSX-DATA
# {
#   "format": "ts-espionnage-save",
#   "version": 1,
#   "capabilities": {
#     "deterministic_replay": true,
#     "engine_resume": false,          ← v1 不恢复引擎阶段栈（v2 才可玩）
#     "private_hands": true,
#     "private_state_derivable_from_seed": true
#   },
#   "position": { ... },               ← 精确局面快照
#   "replay": {"seed": 12345, "actions": ["Poland", "NATO", "PLAY_EVENT"]}
# }
# TSX-END
```

- 每行 JSON 前缀 `# `；解析器兼容旧 v1 单行 `# TSX-DATA {...}`；
- `replay` 仅在选种子时写入；`position.hands/headline/card_state` 仅在选手牌时写入；
- `position` 字段表见 [TSX_SAVE_FORMAT.md](TSX_SAVE_FORMAT.md) §`position` 字段；
  注意 `map` 值顺序固定 `[USSR, US]`；`draw_count` 只存数量不存牌序；
- 未选手牌时，当前输入若为选牌，`options` 以 `"options_redacted": true` 替代；
  弃牌/移除/持续效果/牌堆数量仍写入。

### 6.1 自己产出的最小实现

```
正文（4.x 渲染） + '\n' + '# TSX-BEGIN v1\n# TSX-DATA\n'
+ 每行'# '前缀的 json.dumps(extension, indent=2, sort_keys=True)
+ '\n# TSX-END\n'
```
两级开关（种子/手牌）都可单独关；全关时 `build_save_text` 返回正文逐字不变。

---

## 七、捕获方法（供其他引擎参考）

我们的实现是**输入探针**：monkey-patch `Input.recv`，每次接受一个玩家输入前后对
游戏状态拍轻量快照（地图/轨道/双方手牌/牌堆/持续效果），渲染时把快照序列重组为
SETUP/头条/行动轮块，块与块之间的无输入间隙（事件结算/回合清理）用
"块末对账"补出状态差行；头条事件段用 `dispose_headline` 钩子，事件化触发用
`trigger_event` 钩子。三个要点：

1. **快照而非日志**：不依赖引擎的文本输出——`recv` 前一个快照 + `recv` 后一个
   快照，差行只由快照差生成（可重放、无竞态）；
2. **钩子最小面**：只包 `recv` + 头条 dispose + 事件 trigger 三个入口；
3. **确定性优先**：`replay.actions` 就是 `recv` 的**原始输入串**（卡片名/国家名/
   骰数/元组串），配合种子可完整重建——如果您的引擎本身就支持
   `seed → actions 确定性重放`，甚至不需要探针，直接按 4.x 渲染即可。
   前提：引擎 RNG 确定（新 seed 不初始化系统随机）、动作语义与 4.x 对齐。

## 八、验证清单（产出后必检）

1. **正文语法自检**：`rl.replay_parser.parse_espionnage` 对 TSX 文件产出与纯正文
   相同的决策序列（round-trip 测试 `tests/test_ts_record.py::TestRoundTrip`）；
2. **真实样本锚点**：样本库 `data/txt_replay/TS_Espionnage_log/`（4 局，含各类
   早期/中期事件与陷阱） + **`data/txt_replay/对局记录/`（419 局真实对局，
   30.8 万行）**——本 spec 的以下结论均经后者核实：
   - AR 编号：T1-3=6 轮、T4-10=7 轮、太空 8 格=8 轮；
   - Cleanup 回合号=客户端恒定计数（3..9 不等），与真实回合无关；
   - 政变（含 `(-1)` 修正段双空格变体）、战争（含 `(-m)  >=` 双空格变体）、
     对齐（每方独立修正±0/±1）、陷阱、VP 单行、`No VP awarded.`、
     弃牌无句号、Grain Sales 揭示+返还、竞拍行、Turn Zero 变体行——全部一致；
   - 卡名显示表（21 张特例）逐词一致。
3. **确定性重放**：`seed+actions` 重放到存档点，position 与存档一致
   （`hvs.launch --replay-file ...`）；半途镜像 `<mode>_running.tsg` 每步原子更新也走同管线；
4. **隐私分界**：含 seed/hands 的 `.tsg` 不出局；公开发布只发纯正文 `.txt`；
5. **语法糖特判**：QBT 块、陷阱行、`No VP awarded.`、`*RESHUFFLE*` 位置、
   `Trap Roll` 单双空格与修正段的 `(-1)`。

## 九、独立实现参考代码（不依赖本仓库）

> 你的引擎只需满足两个前提：①一个**接受玩家输入的单一入口**（有 UI/自动化
> 别名字也无妨）；②可对状态做**可序列化快照**（4.x 里差的源头）。若你的引擎
> 已支持 `seed → actions` 确定性重放，连探针都可以省去，直接按第三段写法输出。

### 9.1 输入探针 + 快照差行

```python
# ---------- 挂钩: 引擎接受每个玩家输入的位置(骰子/选牌/选国/选行动) ----------
def on_input(game, input_state, value):
    key = (game.turn, game.ar, input_state.side_name, input_state.kind)
    pre = snapshot(game)                        # 输入前快照
    ok = engine.apply_into(game, value)         # 你的引擎接受该输入
    if ok:
        rows.append(Step(key, value, pre, snapshot(game)))   # 输入后快照

def snapshot(game) -> dict:
    return {
        "vp": game.vp, "defcon": game.defcon, "turn": game.turn, "ar": game.ar,
        "map": {n: [c.ussr, c.us] for n, c in game.countries if c[0] or c[1]},
        "milops": ..., "space": ..., "sidetrack": ..., "basket": ...,
        "hand": {s: list(game.hand[s]) for s in ("USSR", "US")},   # 私有, 仅存档
        "discard": ..., "deck_n": len(game.deck), "done": game.game_over,
    }

# ---------- 渲染: 把 rows 聚合成 4.2-4.7 的块, 差行由前后快照计算 ----------
def diff_lines(a, b):      # 顺序: influence→space→VP→milops→defcon→basket→discards
    for name in sorted(set(a["map"]) | set(b["map"])):
        # "{side} {+n} in {country} [US][USSR]" 按绝对値, US 行先
        ...
    if b["space"] > a["space"]: ...          # "{side} advances to N in the Space Race."
    if b["vp"] != a["vp"]: ...               # "{side} gains N VP. Score is ..."
    if b["milops"] != a["milops"] and b["milops"] > 0: ...   # 归零不输出
    if b["defcon"] != a["defcon"]: ...       # "DEFCON improves|degrades to N"
    for eff in new_or_removed_basket(): ...  # "X* is (now|no longer) in play."
    ...                                      # 弃牌行 "{side} discards X"(无句号)

def render_block(pre, rows_sub, post):
    head = f'Turn {pre["turn"]}, {side} AR{ar}: {card}: {mode} ({ops} Ops):'
    body = diff_lines(rows_sub[0].pre, rows_sub[-1].post)
    return head + "\n" + "\n".join(body)
```

块分组规则（对应 4.2/4.3）：`SELECT_COUNTRY` 且提示含 starting influence →
SETUP 块（连续输入归并）；`SELECT_CARD` 且提示为 Select headline. → 头条块
（两次选牌 + 每事件一段）；普通选牌 → AR 块（按 side/AR 切片——同一 AR 的
美苏行动必须分属两块）；QBT 弃牌提示 → 陷阱块（头部合一 + `Trap Roll`）。

### 9.2 不写探针的确定性引擎

引擎有 `replay(seed, actions)` 时：按 4.x 直接渲染 actions 即可——差行来源退化为
"重放第 k 步前后的状态差"，完全等价。

### 9.3 V1 追加块（最小实现）

```python
import json
def build_v1(body_text, position, *, seed=None, actions=(), hands=None):
    ext = {"format": "ts-espionnage-save", "version": 1, "position": position}
    if seed is not None:                      # seed 与 actions 联动可选
        ext["replay"] = {"seed": seed, "actions": list(map(str, actions))}
    if hands is not None:                     # 必须与 position 一起进私有区
        ext["position"]["hands"] = hands      # {"USSR": [...], "US": [...]}
    payload = json.dumps(ext, ensure_ascii=False, indent=2, sort_keys=True)
    commented = "\n".join("# " + ln for ln in payload.splitlines())
    return (body_text.rstrip("\n") + "\n# TSX-BEGIN v1\n# TSX-DATA\n"
            + commented + "\n# TSX-END\n")
```

要点：正文为纯文本前缀；两条选项（seed / hands）均可单独关闭，全关时逐字
返回正文；`position.position` 字段名与 3.5 的 `position_snapshot` 语义一致
（`map` 值序 `[USSR, US]`；`draw_count` 只存数量；未含 hands 时选牌输入的
`options` 以 `"options_redacted": true` 隐去）。

### 9.4 最少自检（三行）

```python
from rl.replay_parser import parse_espionnage     # 正文必须可解析(纯正文等价)
from ts_save import split_save_text               # TSX 块必须可解析
assert parse_espionnage(path); split_save_text(open(path, encoding="utf-8").read())
# 确定性: replay(seed, actions) 的末步快照 == position
```

## 十、验证工具（随本文档分发）

**`v1_validate.py`** —— 独立单文件验证器（纯 Python 标准库，零仓库依赖），
对任意来源的 .txt/.tsg 输出错误/警告报告并给出退出码（0=通过、1=有错误）：

```powershell
python v1_validate.py game.tsg game.txt ...   # 全量检查
python v1_validate.py --strict game.tsg       # 警告也视为错误(发布前闸门)
python v1_validate.py -q game.tsg             # 只打印错误
```

已验证：419 局真实 TSEspionage 中断导出全部零错误通过（截断/无终局行仅警告）；
本仓库当前生成器的完整 .tsg（seed+双手牌+actions）零错误零警告；修复前的旧
存档（首行 `*RESHUFFLE*` 等历史格式问题）被正确拒绝——它同时是**历史格式
回归门禁**。

**`test_v1_validate.py`** —— 26 个自包含单元测试：合法样例（纯正文/TSX 全
组合/真实客户端行型）、15+ 错误分支（结构/词表/状态量/TSX 承诺与物理唯一性）、
警告判定与 `--strict`/CLI 退出码。拷贝这两个文件即可在任意机器
`pytest test_v1_validate.py` 用于自研生成器验证。

输出合法性检查语义（错误=违反规范硬约束，警告=可疑/历史格式/截断）见
`v1_validate.py` 头部与 §八 清单。
