# TSX V1 存档规范工具包（V1 Save Toolkit）

《冷战热斗》（Twilight Struggle）棋谱/存档的**公开可交换格式**：
标准 TS Espionnage 文本 + 追加的 `# TSX-BEGIN v1` 块。
本工具包让你不用实现任何规则引擎，就能验证任一生成器产出的 V1 文本合法性。

## 内容

| 文件 | 用途 |
| --- | --- |
| `V1_SAVE_FORMAT_SPEC.md` | 完整规范：V1 相对原始 TSEspionage 棋谱的改进、正文行格式全表（含陷阱/政变/对齐/揭示/竞拍等全部真实的 Playdek 客户端行型）、TSX 块字段、捕获方法、验证清单、§九 独立实现参考代码 |
| `v1_validate.py` | 独立验证器：纯 Python 3 标准库，无任何仓库/引擎依赖。对 `.txt`（纯棋谱）与 `.tsg`（V1 存档）输出错误/警告报告与退出码 |
| `test_v1_validate.py` | 26 个自包含单元测试（含合法样例/错误分支/TSX 承诺一致性/`--strict`），用于验证你自己的 V1 生成器 |

## 快速上手

```bash
# 1. 验证一个文件(0=通过, 1=有错误)
python v1_validate.py path/to/your/game.tsg

# 2. 发布前闸门: 警告也视为失败
python v1_validate.py --strict path/to/your/game.tsg

# 3. 跑测试(需 pytest; 也可用任何 pytest 兼容 runner)
pip install pytest
pytest test_v1_validate.py -q
```

## 关键语义

- **正文 = 标准 TS Espionnage**：任何旧的 TSEspionage 文本工具都能直接读取；
  TSX 块是逐行 `# ` 注释的 JSON，旧工具当注释忽略。
- **两个可选项**：`replay`（seed + 动作序列，确定性重放）与 `hands`（双方手牌/
  头条，私有）。都可单独关闭——全关时正文逐字不变。
- **错误 vs 警告**：错误 = 违反规范硬约束（行型/结构/状态量/TSX 承诺）；
  警告 = 可疑或历史格式（无终局行的半途导出、Turn Zero 场景牌、未知卡名等）。
- **已核实**：419 局真实 Playdek 客户端导出（TSEspionage MOD 输出）零错误通过
  （截断/中断局仅警告）；本工具支持的真实行型集（AR 编号 6/7/8 轮规则、Cleanup
  回合号怪癖、Grain Sales 揭示+返还、竞拍行等）均来自真实样本统计。

## 生成器实现提示

如果你只想要“我的引擎也能输出 V1”，见规范 §九：确定性引擎（`seed → actions`）
可以直接按行格式渲染，甚至不需要输入探针；最低要求是接受玩家输入的单一入口
+ 可序列化快照。
